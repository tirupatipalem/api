from django.urls import path


from EmployeeApp import views



from rest_framework_jwt.views import obtain_jwt_token,refresh_jwt_token,verify_jwt_token




urlpatterns = [
	
	path('emp-api/',views.EmployeeListCreateAPIView.as_view()),
	path('emp-api/<str:pk>/',views.EmployeeRetrieveUpdateDestroyAPIView.as_view()),
	path('dept-api/',views.DepartmentListCreateAPIView.as_view()),
	path('dept-api/<str:pk>/',views.DepartmentRetrieveUpdateDestroyAPIView.as_view()),
	path('auth-jwt/',obtain_jwt_token),
	path('auth-jwt-refresh/',refresh_jwt_token),
	path('auth-jwt-verify/',verify_jwt_token),
]

