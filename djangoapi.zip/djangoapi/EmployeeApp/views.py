from django.shortcuts import render
from rest_framework.views import APIView
from . models import Departments,Employees
from . serializers import *

from rest_framework.response import Response

from rest_framework.generics import ListCreateAPIView,RetrieveUpdateDestroyAPIView

from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated

class EmployeeListCreateAPIView(ListCreateAPIView):
    queryset=Employees.objects.all()
    serializer_class=EmployeeSerializer
    authentication_classes = [JSONWebTokenAuthentication,]
    permission_classes = [IsAuthenticated,]
    

class EmployeeRetrieveUpdateDestroyAPIView(RetrieveUpdateDestroyAPIView):
    queryset=Employees.objects.all()
    serializer_class=EmployeeSerializer 
    authentication_classes = [JSONWebTokenAuthentication,]
    permission_classes = [IsAuthenticated,]



class DepartmentListCreateAPIView(ListCreateAPIView):
    queryset=Departments.objects.all()
    serializer_class=DepartmentSerializer
    authentication_classes = [JSONWebTokenAuthentication,]
    permission_classes = [IsAuthenticated,]
    

class DepartmentRetrieveUpdateDestroyAPIView(RetrieveUpdateDestroyAPIView):
    queryset=Departments.objects.all()
    serializer_class=DepartmentSerializer     