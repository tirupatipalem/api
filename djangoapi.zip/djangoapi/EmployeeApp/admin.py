from django.contrib import admin
from . models import Departments,Employees
# Register your models here.

class DeparmentAdmin(admin.ModelAdmin):
    list_display=('DepartmentId','DepartmentName')

class EmployeeAdmin(admin.ModelAdmin):
    class Meta:
        model=Employees
        fields='__all__'

admin.site.register(Departments,DeparmentAdmin)    
admin.site.register(Employees,EmployeeAdmin)    