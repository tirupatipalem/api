from django.shortcuts import render
from rest_framework import generics
from . models import Employee
from . serializers import EmployeeSerializer


# Create your views here.

# class EmployeeAPIView(generics.ListAPIView):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
    
from rest_framework.pagination import PageNumberPagination


#************

# class MyPagination(PageNumberPagination):
#     page_size=5
    


# class EmployeeAPIView(generics.ListAPIView):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     pagination_class = MyPagination

#*********************








#*****************

# class MyPagination(PageNumberPagination):
#     page_size=5
#     page_query_param ='mypage'


# class EmployeeAPIView(generics.ListAPIView):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     pagination_class = MyPagination
 
#************************** 




#*********************

# class MyPagination(PageNumberPagination):
#     page_size=5
#     page_query_param ='mypage'
#     page_size_query_param='num'


# class EmployeeAPIView(generics.ListAPIView):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     pagination_class = MyPagination
 
#************************ 



#*********************

#http://127.0.0.1:8000/api/?mypage=2&num=15

# class MyPagination(PageNumberPagination):
#     page_size=5
#     page_query_param ='mypage'
#     page_size_query_param='num'
#     max_page_size=15


# class EmployeeAPIView(generics.ListAPIView):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     pagination_class = MyPagination
 
#************************ 


#*********************
#http://127.0.0.1:8000/api/?mypage=endpage&num=20

# class MyPagination(PageNumberPagination):
#     page_size=5
#     page_query_param ='mypage'
#     page_size_query_param='num'
#     max_page_size=15
#     last_page_strings=('endpage')


# class EmployeeAPIView(generics.ListAPIView):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     pagination_class = MyPagination
 
#************************ 



from testapp.pagination import MyPagination

#paginaton.py

# class EmployeeAPIView(generics.ListAPIView):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     pagination_class = MyPagination
 
 
from testapp.pagination import MyPagination2


class EmployeeAPIView(generics.ListAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    pagination_class = MyPagination2
 