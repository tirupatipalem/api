from django.apps import AppConfig


class JwtappConfig(AppConfig):
    name = 'jwtapp'
