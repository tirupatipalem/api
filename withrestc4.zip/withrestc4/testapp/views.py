from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
from . models import Employee
from . serializers import EmployeeSerializer

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated

from rest_framework.permissions import AllowAny,IsAdminUser,IsAuthenticatedOrReadOnly
from rest_framework.permissions import DjangoModelPermissions,DjangoModelPermissionsOrAnonReadOnly

# Create your views here.

class EmployeeCRUDCBV(ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    # authentication_classes = [TokenAuthentication,]
    # permission_classes = [IsAuthenticated,]


# class EmployeeCRUDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     authentication_classes = [TokenAuthentication,]
#     permission_classes = [AllowAny,]

# class EmployeeCRUDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     authentication_classes = [TokenAuthentication,]
#     permission_classes = [IsAdminUser,]

# class EmployeeCRUDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     authentication_classes = [TokenAuthentication,]
#     permission_classes = [IsAuthenticatedOrReadOnly,]

# class EmployeeCRUDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     authentication_classes = [TokenAuthentication,]
#     permission_classes = [DjangoModelPermissions,]

# class EmployeeCRUDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     authentication_classes = [TokenAuthentication,]
#     permission_classes = [DjangoModelPermissionsOrAnonReadOnly,]

# from testapp.permissions import IsReadOnly

# class EmployeeCRUDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     authentication_classes = [TokenAuthentication,]
#     permission_classes = [IsReadOnly,]

# from testapp.permissions import IsGETOrPatch


# class EmployeeCRUDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     authentication_classes = [TokenAuthentication,]
#     permission_classes = [IsGETOrPatch,]


# from testapp.permissions import SrikanthPermission


# class EmployeeCRUDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     authentication_classes = [TokenAuthentication,]
#     permission_classes = [SrikanthPermission,]

# from rest_framework_jwt.authentication import JSONWebTokenAuthentication


# class EmployeeCRUDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeSerializer
#     authentication_classes = [JSONWebTokenAuthentication]
#     permission_classes = [IsAuthenticated,]
